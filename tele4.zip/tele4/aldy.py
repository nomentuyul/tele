from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.errors import SessionPasswordNeededError
from time import sleep
from bs4 import BeautifulSoup
import re,sys,os,time,colorama,random,json,threading,itertools,requests,traceback

with open ("cfg.json", "r") as fh:
  json_str = fh.read()
  json_value = json.loads(json_str)
  ltcwallet = json_value["walletltc"]
  dogewallet = json_value["walletdoge"]
  btcwallet = json_value["walletbtc"]

def mengetik(s):
	for c in s+"\n":
		sys.stdout.write(c)
		sys.stdout.flush()
		time.sleep(random.random()*0.1)


def tunggu(x):
		sys.stdout.write("\r")
		sys.stdout.write("                                                               ")
		for remaining in range(x, 0, -1):
			 sys.stdout.write("\r")
			 sys.stdout.write("\x1b[1;35mSTATUS VISIT    \x1b[39m: \x1b[1;36mWait \x1b[1;32m{:2d} \x1b[1;36mseconds ".format(remaining))
			 sys.stdout.flush()
			 sleep(1)

banner = "INI BANNER"
os.system("clear")
print(banner)
print ("\x1b[94mCONFIGURATION SETTING \x1b[39m: \x1b[93mAUTO JOIN, VISIT & WD CLICKBOT")

def password ():
	c = requests.Session()
	if not os.path.exists(".password"):
		os.makedirs(".password")
	pw = "nomen"
	if not os.path.exists(".password/password.txt"):
		f = open(".password/password.txt", "w+")
		f.write("File_Ready")
		f.close()
	for i in range(99):
		f = open(".password/password.txt", "r")
		if f.readlines()[0] == pw:
			break
		
		pwin = input("\x1b[1;35mLINK PASSWORD         \x1b[1;36m: https://bit.ly/2UQHGfo\n\x1b[1;35mINPUT PASSWORD        \x1b[1;36m: ")
		if pwin == pw:
			f = open(".password/password.txt", "w+")
			f.write(pwin)
			f.close()
			print("\x1b[1;35mSTATUS                \x1b[1;36m: Correct Password")
			break
		else:
			print("\x1b[1;35mSTATUS                \x1b[1;36m: Wrong Password\n")
			sys.exit()

password()
currency= "doge"
if (currency=="doge") or (currency=="ltc") or (currency=="btc"):
	print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
else:
	print("\x1b[1;35mSTATUS                \x1b[1;36m: Wrong Input \n")
	sys.exit()
print(colorama.ansi.clear_screen())
done = False

def animate() :
	for c in itertools.cycle(["|","/","-","\\"]): 
		if done :
			break
		sys.stdout.write("\x1b[1;34m\rloading "+c)
		sys.stdout.flush()
		time.sleep(0.1)
	sys.stdout.write("\rDone!     ")
t = threading.Thread(target= animate)
t.start()
time.sleep(2)
done = True
lines = [
"iIkan Hiu Makan Tomat"]
for line in lines :
	for c in line :
		print(c,end= "")
		sys.stdout.flush()
		time.sleep(0.1)
	print('\n')
	sleep(2)

if not os.path.exists("session"):
	os.makedirs("session")

os.system("clear")
r = requests.get("https://ipinfo.io/json")
data = json.loads(r.text)
text = ("\x1b[34mYOUR LOCATION\t\x1b[39m: \x1b[1;33m{1}\t({2})\n\x1b[34mYOUR OWN IP\t\x1b[39m: \x1b[1;33m{0}")
text = text.format(data.get("ip","[NO DATA]"), data.get("region","[NO DATA]"), data.get("country","[NO DATA]"))
print(banner)
mengetik(text)
mengetik("\x1b[34mWELCOME TO BOT  \x1b[39m: \x1b[1;33mJoin, Visit, Wd Clickbot\n\x1b[0;31mNOTE            \x1b[39m: \x1b[1;31mAldy Anjeng\x1b[39m.......!\n")
ua={"User-Agent": "Mozilla/5.0 (Linux; Android 5.1; A1603 Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36"}
api_id = 800812
api_hash = 'db55ad67a98df35667ca788b97f771f5'

def Withdraw():
	sys.stdout.write("\r")
	sys.stdout.write("                                                              ")
	sys.stdout.write("\r")
	sys.stdout.write("\x1b[34mSTATUS WD       \x1b[39m: \x1b[1;36mGathering info ... !")
	sys.stdout.flush()
	client.send_message(entity=channel_entity,message="/balance")
	sleep(5)
	posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
	message = posts.messages[0].message
	bal = re.findall( r'([\d.]*\d+)', message)[0]
	client.send_message(entity=channel_entity,message="/withdraw")
	sleep(5)
	posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
	if posts.messages[0].message.find("Your balance is too small to") != -1:
		sys.stdout.write(f"\r\x1b[34mSTATUS WD       \x1b[39m: \x1b[1;36mBalance is too small {bal} {cr}\n\n")
		sleep(5)
	else:
		client.send_message(entity=channel_entity,message=wallet)
		sleep(5)
		client.send_message(entity=channel_entity,message=bal)
		sleep(5)
		client.send_message(entity=channel_entity,message="/confirm")
		sys.stdout.write(f"\r\x1b[34mSTATUS WD       \x1b[39m: \x1b[1;36mSuccess withdraw {bal} {cr}\n\n")
		sleep(5)

def Visit():
	c = requests.Session()
	for i in range(5000000):
		sys.stdout.write("\r")
		sys.stdout.write("                                                              ")
		sys.stdout.write("\r")
		sys.stdout.write("\x1b[34mSTATUS VISIT    \x1b[39m: \x1b[1;36mGathering data \x1b[39m... !")
		sys.stdout.flush()
		client.send_message(entity=channel_entity,message="/visit")
		sleep(3)
		posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
		if posts.messages[0].message.find("Sorry, there are no new ads available. 😟") != -1:
			break
		else:
		  try:
		  	url = posts.messages[0].reply_markup.rows[0].buttons[0].url
		  	sys.stdout.write("\r")
		  	sys.stdout.write(f"\x1b[34mSTATUS VISIT    \x1b[39m: \x1b[93m{url}")
		  	sys.stdout.flush()
		  	id = posts.messages[0].id
		  	r = c.get(url, headers=ua, timeout=15, allow_redirects=True)
		  	soup = BeautifulSoup(r.content,"html.parser")
		  	if soup.find("div",class_="g-recaptcha") is None and soup.find("div", id="headbar") is None:
		  		sleep(2)
		  		posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
		  		message = posts.messages[0].message
		  		if posts.messages[0].message.find("You must stay") != -1 or posts.messages[0].message.find("Please stay on") != -1:
		  			sec = re.findall( r"([\d.]*\d+)", message)
		  			tunggu(int(sec[0]))
		  			sleep(1)
		  			posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
		  			messageres = posts.messages[1].message
		  			reward = re.findall( r"([\d.]*\d+)", messageres)[0]
		  			sleep(2)
		  			sys.stdout.write(f"\r\x1b[34mSTATUS VISIT    \x1b[39m: \x1b[1;36mYou earned \x1b[32m{reward} \x1b[1;36m{cr} \n")
		  		else:
		  			pass

		  	elif soup.find("div", id="headbar") is not None:
		  		for dat in soup.find_all("div",class_="container-fluid"):
		  			code = dat.get("data-code")
		  			timer = dat.get("data-timer")
		  			tokena = dat.get("data-token")
		  			tunggu(int(timer))
		  			r = c.post("https://dogeclick.com/reward",data={"code":code,"token":tokena}, headers=ua, timeout=15, allow_redirects=True)
		  			js = json.loads(r.text)
		  			sys.stdout.write("\r\x1b[34mSTATUS VISIT    \x1b[39m: \x1b[1;36mYou earned" +js["reward"]+f" {cr} \n")
		  	else:
		  		sys.stdout.write("\r")
		  		sys.stdout.write("                                                               ")
		  		sys.stdout.write("\r")
		  		sys.stdout.write("\x1b[1;35mSTATUS VISIT    \x1b[39m: \x1b[91mCaptcha Detected")
		  		sys.stdout.flush()
		  		sleep(2)
		  		client(GetBotCallbackAnswerRequest(
		  			channel_username,
		  			id,
		  			data=posts.messages[0].reply_markup.rows[1].buttons[1].data
		  			))
		  		sys.stdout.write("\r\x1b[34mSTATUS VISIT    \x1b[39m: \x1b[31mSkip captcha \x1b[39m... !\n")
		  		sleep(2)
		  except:
		 		sleep(3)
		 		posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
		 		message = posts.messages[0].message
		 		if posts.messages[0].message.find("You must stay") != -1 or posts.messages[0].message.find("Please stay on") != -1:
		 			sec = re.findall( r"([\d.]*\d+)", message)
		 			tunggu(int(sec[0]))
		 			sleep(1)
		 			posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
		 			messageres = posts.messages[1].message
		 			reward = re.findall( r"([\d.]*\d+)", messageres)[0]
		 			sleep(2)
		 			sys.stdout.write(f"\r\x1b[34mSTATUS VISIT    \x1b[39m: \x1b[1;36mYou earned \x1b[32m{reward} \x1b[1;36m{cr} \n")
		 		else:
		 			pass

def Join():
	for i in range(10):
		sys.stdout.write("\r")
		sys.stdout.write("                                                              ")
		sys.stdout.write("\r")
		sys.stdout.write("\x1b[94mSTATUS JOIN\x1b[24m     \x1b[39m: \x1b[1;36mGathering channel \x1b[39m... !")
		sys.stdout.flush()
		client.send_message(entity=channel_entity,message="/join")
		sleep(5)
		posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
		messag = posts.messages[0].message
		msg_id = posts.messages[0].id
		if posts.messages[0].message.find("Sorry, there are no new ads available. ") != -1:
			sleep(5)
		else:
			try:
				bot = re.search(r"You must join (.*?) to earn", messag).group(1)
				channel_name = client.get_entity(bot)
				client(JoinChannelRequest(channel_name))
				sleep(3)
				client(GetBotCallbackAnswerRequest(
					channel_entity,
					msg_id,
					data=posts.messages[0].reply_markup.rows[0].buttons[1].data
					))
				sys.stdout.write("\r")
				sys.stdout.write("                                                                ")
				sys.stdout.write("\r")
				sys.stdout.write(f"\x1b[4m\x1b[94mSTATUS JOIN\x1b[24m     \x1b[39m: \x1b[95mJoining \x1b[93m{bot} ")
				sys.stdout.flush()
				sleep(5)
				posts_ = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
				id = posts_.messages[1].id
				msg = posts_.messages[1].message
				musang = re.findall( r"([\d.]*\d+)", msg)[0]
				if posts.messages[0].message.find("We cannot find you in the group.") != -1:
					client(GetBotCallbackAnswerRequest(
						channel_entity,
						id,
						data=posts.messages[1].reply_markup.rows[1].buttons[1].data
						))
					sys.stdout.write("\r")
					sys.stdout.write("                                                                ")
					sys.stdout.write("\r")
					sys.stdout.write("\r\x1b[4m\x1b[94mSTATUS JOIN\x1b[24m     \x1b[39m: \x1b[1;31mSkip task \x1b[39m... !          \n")
					sleep(5)
				else:
					if int(musang)>168:
						break
					else:
						sys.stdout.write("\r")
						sys.stdout.write("                                                                ")
						sys.stdout.write("\r")
						sys.stdout.write(f"\r\x1b[4m\x1b[94mSTATUS JOIN\x1b[24m     : \x1b[1;36mEarned after {musang} hours          \n")
						sleep(5)
			except Exception:
				client(GetBotCallbackAnswerRequest(
						channel_entity,
						msg_id ,
						data=posts.messages[0].reply_markup.rows[1].buttons[1].data
						))
			except errors.FloodWaitError as e:
				sys.stdout.write(f"\r\x1b[94mSTATUS BOT     \x1b[39m: \x1b[1;36mMust sleep {e.seconds} seconds\n")
				break
			except Exception:
				client(GetBotCallbackAnswerRequest(
						channel_entity,
						msg_id ,
						data=posts.messages[0].reply_markup.rows[1].buttons[1].data
						))
						

			


f= open("nomor.txt")
baris = len (f.readlines())
f.close()

for i in range(baris):
	f= open("nomor.txt")
	phone_number = f.readlines()[i].strip()
	f.close()
	mengetik("INFO AKUN")
	print(f"\x1b[34mYOUR NUMBER     : \x1b[1;36m{phone_number}\n")
	client = TelegramClient('session/'+phone_number, api_id, api_hash)
	client.connect()
	if not client.is_user_authorized():
		try:
			client.send_code_request(phone_number)
			me = client.sign_in(phone_number, input("\x1b[1;35mVERIF CODE      \x1b[39m: \x1b[1;36m"))
		except SessionPasswordNeededError:
			passw = input("\x1b[1;35m2FA CODE        \x1b[39m: \x1b[1;36m")
			me = client.start(phone_number,passw)
		except Exception:
			sleep(3)
	myself = client.get_me()
	try:
		if currency=="doge" :
			channel_entity=client.get_entity("@Dogecoin_click_bot")
			channel_username="@Dogecoin_click_bot"
			cr = "DOGE"
			wallet = dogewallet	
		Visit()
		Withdraw()

	except Exception:
		sys.stdout.write("\r\x1b[1;35mSTATUS AKUN     \x1b[39m: \x1b[1;36mSomething Wrong happened !\n\n")
	finally:
		client.disconnect()
		sleep(2)