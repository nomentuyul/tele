from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.errors import SessionPasswordNeededError
from telethon.errors import FloodWaitError
from time import sleep
import json,re,sys,os,requests,time,random,colorama,threading,itertools
from bs4 import BeautifulSoup

with open ("cfg.json", "r") as fh:
  json_str = fh.read()
  json_value = json.loads(json_str)
  ltcwallet = json_value["walletltc"]
  dogewallet = json_value["walletdoge"]
  btcwallet = json_value["walletbtc"]

print("\n\n\x1b[1;32mclear")
print("\x1b[1;35mBot nuyul bot telegram")
time.sleep(1)
print(colorama.ansi.clear_screen())
done = False

def animate() :
	for c in itertools.cycle(["|","/","-","\\"]): 
		if done :
			break
		sys.stdout.write("\x1b[1;34m\rloading "+c)
		sys.stdout.flush()
		time.sleep(0.1)
	sys.stdout.write("\rDone!     ")
t = threading.Thread(target= animate)
t.start()
time.sleep(2)
done = True
lines = [
" \x1b[31mSelamat bekerja \x1b[33mdan \x1b[32mtetap semangat.....!?"]
for line in lines :
	for c in line :
		print(c,end= "")
		sys.stdout.flush()
		time.sleep(0.1)
	print('\n')
	sleep(1)

c = requests.Session()
if not os.path.exists("session"):
		os.makedirs("session")

if len(sys.argv)<2:
	 print ("\n\n\n\033[1;32mUsage : python main.py +62 doge")
	 sys.exit(1)

ua={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"}

api_id = 1837080
api_hash = '51a545e58036164a316a3beb232897f0'
phone_number = sys.argv[1]
pilihan = sys.argv[2]

def tunggu(x):
		sys.stdout.write("\r")
		sys.stdout.write("                                                               ")
		for remaining in range(x, 0, -1):
			 sys.stdout.write("\r")
			 sys.stdout.write("\x1b[1;35mSTATUS VISIT    : \x1b[1;36mWait \x1b[1;32m{:2d} \x1b[1;36mseconds ".format(remaining))
			 sys.stdout.flush()
			 sleep(1)

def mengetik(s):
	for c in s+"\n":
		sys.stdout.write(c)
		sys.stdout.flush()
		time.sleep(random.random()*0.1)

client = TelegramClient("session/"+phone_number, api_id, api_hash)
client.connect()
if not client.is_user_authorized():
	try:
		client.send_code_request(phone_number)
		me = client.sign_in(phone_number, input('\n\n\n\033[1;0mEnter Your Code : '))
	except SessionPasswordNeededError:
		passw = input("\033[1;0mYour 2fa Password : ")
		me = client.start(phone_number,passw)
myself = client.get_me()
os.system("clear")
banner = "\x1b[0;31m╔╗╔╗────────╔══╗╔═╦╦╗────╔══╗────╔╗\n\x1b[33m║╚╝╠═╦═╦═╦═╗║╔╗║║║║╠╬═╦═╗╚╗╗╠═╗╔╦╣║\n\x1b[34m║╔╗║╬╚╗║╔╣╩╣║╠╣║║║║║║═╣╩╣╔╩╝║╬╚╣║║║\n\x1b[32m╚╝╚╩══╩═╝╚═╝╚╝╚╝╚╩═╩╩═╩═╝╚══╩══╬╗╠╣\n\x1b[36m───────────────────────────────╚═╩╝\x1b[0m\n"
r = requests.get("https://ipinfo.io/json")
data = json.loads(r.text)
text = ("\x1b[34mYOUR LOCATION\t: \x1b[1;33m{1}\t({2})\n\x1b[34mYOUR OWN IP\t: \x1b[1;33m{0}")
text = text.format(data.get("ip","[NO DATA]"), data.get("region","[NO DATA]"), data.get("country","[NO DATA]"))
print(banner)
mengetik(text)
mengetik(f"\x1b[1;35mWELCOME         :\x1b[1;36m {myself.first_name}\n\x1b[1;35mYOUR NUMBER     :\x1b[1;36m {phone_number}")
try:
	if pilihan=="doge" :
		channel_entity=client.get_entity("@Dogecoin_click_bot")
		channel_username= "@Dogecoin_click_bot"
		currency = "DOGE"
		dompet = dogewallet
	if pilihan=="ltc" :
		channel_entity=client.get_entity("@Litecoin_click_bot")
		channel_username="@Litecoin_click_bot"
		currency = "LTC"
		dompet = ltcwallet
	if pilihan=="btc" :
		channel_entity=client.get_entity("@BitcoinClick_bot")
		channel_username="@BitcoinClick_bot"
		currency = "BTC"
		dompet = btcwallet

		def withdraw():
			mengetik("\x1b[1;36m============================= \x1b[1;32m(WITHDRAW BALANCE)\n")
			for i in range(5000000):
				sys.stdout.write("\r")
				sys.stdout.write("                                                              ")
				sys.stdout.write("\r")
				sys.stdout.write("\x1b[1;30m[\x1b[1;33m!\x1b[1;30m] \x1b[1;33mTrying to withdraw")
				sys.stdout.flush()
				client.send_message(entity=channel_entity,message="/Balance")
				sleep(1)
				posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
				message = posts.messages[0].message
				doge_msg = message
				doge_bal = doge_msg.strip("Available balance: ")
				sleep(1)
				client.send_message(entity=channel_entity,message="/withdraw")
				sleep(1)
				posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
				if posts.messages[0].message.find("Your balance is too small to") != -1:
					sys.stdout.write(f"\r\x1b[1;30m[\x1b[1;33m-\x1b[1;30m] \x1b[1;33m{doge_msg}\n")
					sys.exit()
					client.send_message(entity=channel_entity,message="dompet")
					sleep(1)
					client.send_message(entity=channel_entity,message="doge_msg")
					sleep(1)
					client.send_message(entity=channel_entity,message="/Confirm")
					sys.stdout.write(f"\r\x1b[1;30m[\x1b[1;32m+\x1b[1;30m] \x1b[1;32mSucces withdraw {doge_bal} {channel_username}\n")
					sys.exit()

		
		def join():
			mengetik("\x1b[1;36m================================== \x1b[1;32m(JOINING BOT)\n")
			for i in range(10):
				sys.stdout.write("\r")
				sys.stdout.write("                                                              ")
				sys.stdout.write("\r")
				sys.stdout.write("\x1b[1;30m[\x1b[1;33m!\x1b[1;30m] \x1b[1;33mTrying to get an url")
				sys.stdout.flush()
				client.send_message(entity=channel_entity,message="ðŸ“£ Join chats")
				sleep(3)
				posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
				if posts.messages[0].message.find("Sorry, there are no new ads available") != -1:
					messag = posts.messages[0].message
					msg_id = posts.messages[0].id
					sys.stdout.write("\r\x1b[1;30m[\x1b[1;31mx\x1b[1;30m] \x1b[1;31mSorry, there are no new ads available. \x1a\n\n")
					visit()
						
					bot = re.search(r"You must join (.*?) to earn", messag).group(1)
					channel_name = client.get_entity(bot)
				else:
					try:
						client(JoinChannelRequest(channel_name))
						sleep(2)
						client(GetBotCallbackAnswerRequest(
							channel_entity,
							msg_id,
							data=posts.messages[0].reply_markup.rows[0].buttons[1].data
							))
						sys.stdout.write("\r")
						sys.stdout.write("                                                                ")
						sys.stdout.write("\r")
						sys.stdout.write(f"\x1b[1;30m[\x1b[1;33m-\x1b[1;30m] \x1b[1;33mJoining bot {bot} ")
						sys.stdout.flush()
						sleep(5)
						posts_ = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
						id = posts_.messages[1].id
						msg = posts_.messages[1].message
						musang = re.findall( r"([\d.]*\d+)", msg)[0]
						if posts.messages[0].message.find("cannot find you") != -1:
							client(GetBotCallbackAnswerRequest(
								channel_entity,
								id,
								data=posts.messages[1].reply_markup.rows[1].buttons[1].data
								))
							sys.stdout.write("\r")
							sys.stdout.write("                                                                ")
							sys.stdout.write("\r")
							sys.stdout.write("\r\x1b[1;30m[\x1b[1;31mx\x1b[1;30m] \x1b[1;31mSkip task...!                                                            \n")
							sleep(5)
							sys.stdout.write(f"\r\x1b[4m\x1b[94mSTATUS JOIN\x1b[24m     : \x1b[1;36mEarned after {musang} hours          \n")
							sleep(5)
					except Exception:
						client(GetBotCallbackAnswerRequest(
							channel_entity,
							msg_id ,
							data=posts.messages[0].reply_markup.rows[1].buttons[1].data
							))
					except errors.FloodWaitError as e:
						sys.stdout.write(f"\r\x1b[1;30m[\x1b[1;33m!\x1b[1;30m] \x1b[1;33m{channel_username}Must sleep {e.seconds} seconds\n\n")
						sys.exit()
					except Exception:
						client(GetBotCallbackAnswerRequest(
							channel_entity,
							msg_id ,
							data=posts.messages[0].reply_markup.rows[1].buttons[1].data
							))
						sys.stdout.write("\r\x1b[1;30m[\x1b[1;31mx\x1b[1;30m] \x1b[1;31mSorry, there are no new ads available. \x1a\n\n")
						sys.exit()

		def mesg():
			mengetik("\x1b[1;36m================================ \x1b[1;32m(MESSAGING BOT)\n")
			for i in range(5000000):
				sys.stdout.write("\r")
				sys.stdout.write("                                                              ")
				sys.stdout.write("\r")
				sys.stdout.write("\x1b[1;30m[\x1b[1;33m!\x1b[1;30m] \x1b[1;33mTrying to messaging channel")
				sys.stdout.flush()
				client.send_message(entity=channel_entity,message="Message Bot")
				sleep(2)
				posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
				if posts.messages[0].message.find("Sorry, there are no new ads available") != -1:
					sys.stdout.write("\r\x1b[1;30m[\x1b[1;31mx\x1b[1;30m] \x1b[1;31mSorry, there are no new ads available. \x1a\n\n")
					join()
				else:
					try:
						url = posts.messages[0].reply_markup.rows[0].buttons[0].url
						r = c.get(url, headers=ua, timeout=15, allow_redirects=True)
						soup = BeautifulSoup(r.content,"html.parser")
						dat = soup.find("div",class_="tgme_page_extra")
						bot = dat.text.strip()
						channel_name = client.get_entity(bot)
						sys.stdout.write("\r")
						sys.stdout.write("                                                              ")
						sys.stdout.write("\r")
						sys.stdout.write("\x1b[1;30m[\x1b[1;33m!\x1b[1;30m] \x1b[1;33mTrying to messaging channel")
						sys.stdout.flush()
						sleep(2)
						client.send_message(entity=channel_name,message="/start")
						sleep(2)
						posts_ = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
						msg_id = posts_.messages[0].id
						client.forward_messages(channel_entity,msg_id,channel_name)
						sleep(2)
								
						posts__ = client(GetHistoryRequest(peer=channel_entity,limit=3,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
						msg = posts__.messages[1].message
						msgc = posts__.messages[0].message
						id = posts__.massages[2].id
						if posts__.messages[0].message.find("not a valid") != -1:
							client(GetBotCallbackAnswerRequest(
								channel_entity,
								id ,
								data=posts__.messages[2].reply_markup.rows[1].buttons[1].data
								))
							sys.stdout.write("\r\x1b[1;30m[\x1b[1;31mx\x1b[1;30m] \x1b[1;31mSkip task...!                                                            \n")
							sleep(2)
							sys.stdout.write(f"\r\x1b[1;30m[\x1b[1;32m+\x1b[1;30m] \x1b[1;32m{msg}\n")
							sleep(2)
					except Exception:
						sys.stdout.write("\r\x1b[1;30m[\x1b[1;31mx\x1b[1;30m] \x1b[1;31mSorry, there are no new ads available. \x1a\n\n")
						join()

		try:
			mengetik(f"\x1b[1;35mBOT             : \x1b[1;36m{channel_name}\n")
			mesg()
		except Exception:
			mengetik("\x1b[1;35mBOT             : \x1b[1;36m\n")
			mesg()
			
except errors.FloodWaitError as e :
	sys.stdout.write(f"\r\x1b[1;30m[\x1b[1;33m!\x1b[1;30m] \x1b[1;33maccount must sleep {e.seconds} seconds\n")

finally:
	client.disconnect()